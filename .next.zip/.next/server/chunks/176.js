"use strict";
exports.id = 176;
exports.ids = [176];
exports.modules = {

/***/ 5696:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export SubmitForm */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6107);
/* harmony import */ var lib_Storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6855);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_2__]);
lib_Axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const LoginBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 458px;
  border: 1px solid;
  border: 1px solid #c6c6c6;
  border-radius: 6px;
  background-color: #fff;
  box-shadow: 0 5px 8px 0 rgb(68 68 68 / 4%);

  @media (max-width: 768px) {
    width: 80%;
    margin: 0 auto;
  }
`;
const LoginPanel = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  padding: 20px 28px;
  @media (max-width: 768px) {
    padding: 18px;
  }
`;
const IdBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  height: 48px;
  align-items: center;
  border: 1px solid #dadada;
  border-radius: 6px 6px 0 0;

  @media (max-width: 768px) {
    height: 40px;
  }
`;
const PasswordBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  align-items: center;
  border: 1px solid #dadada;
  border-radius: 0 0 6px 6px;
  height: 48px;
  @media (max-width: 768px) {
    height: 40px;
  }
`;
const Input = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().input)`
  margin-left: 10px;
  width: 100%;
  border: none;
`;
const SubmitButton = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().button)`
  display: block;
  margin-top: 20px;
  width: 100%;
  padding: 13px 0 13px;
  border-radius: 6px;
  border: solid 1px rgba(0, 0, 0, 0.15);
  background-color: skyblue;
  box-sizing: border-box;
  font-size: 20px;
  font-weight: 700;
  line-height: 24px;
  color: #fff;

  @media (max-width: 768px) {
    font-size: 16px;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 40px;
  }
`;
const SubmitForm = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().form)`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
`;
const SignUpWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;

  @media (max-width: 768px) {
    width: 80%;
  }
`;
const SignUpButton = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().button)`
  font-size: 16px;
  margin-top: 20px;
  align-items: center;
  border: none;
  outline: none;
  background: none;

  @media (max-width: 768px) {
    margin-top: 15px;
    font-size: 12px;
  }
`;
const Logo = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  @media (max-width: 768px) {
    width: 120px;
    height: 120px;
  }
`;
const Login = ({ onSubmit  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [form, setForm] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
        id: "",
        password: ""
    });
    const handleId = (e)=>{
        const { value  } = e.target;
        setForm({
            ...form,
            id: value
        });
    };
    const handlePassword = (e)=>{
        const { value  } = e.target;
        setForm({
            ...form,
            password: value
        });
    };
    const handleSubmit = (e)=>{
        console.log(form);
        e.preventDefault();
        onSubmit(form);
        lib_Axios__WEBPACK_IMPORTED_MODULE_2__/* .client.post */ .L.post("/user/login", {
            user_id: id,
            password: password
        }).then((response)=>{
            console.log(response.data);
            console.log(response.status);
            console.log(response.data.token);
            if (response.status === 200) {
                localStorage.setItem("volleyball-token", lib_Storage__WEBPACK_IMPORTED_MODULE_5__/* .TestToken */ .F);
                alert("로그인 성공!");
                console.log((0,lib_Storage__WEBPACK_IMPORTED_MODULE_5__/* .getToken */ .L)());
                router.push("/team/men");
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    };
    const { id , password  } = form;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubmitForm, {
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        paddingBottom: "48px"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Logo, {
                        src: "https://i.imgur.com/BAjHmEF.jpeg",
                        width: 240
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoginBox, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LoginPanel, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IdBox, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Input, {
                                    placeholder: "아이디를 입력하세요",
                                    value: id,
                                    onChange: handleId
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PasswordBox, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Input, {
                                    placeholder: "비밀번호를 입력하세요",
                                    type: "password",
                                    value: password,
                                    onChange: handlePassword
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubmitButton, {
                                children: "로그인"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SignUpWrapper, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SignUpButton, {
                            children: "비밀번호 찾기"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SignUpButton, {
                            children: "회원가입"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8321:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Register = ()=>{
    return /*#__PURE__*/ _jsx("div", {
        children: "Register"
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Register)));


/***/ }),

/***/ 7550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* eslint-disable @next/next/no-img-element */ 


const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 140px;
  background-color: #fff;
  gap: 100px;

  @media (max-width: 768px) {
    gap: 50px;
    height: 100px;
  }
`;
const NavContent = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default()((next_link__WEBPACK_IMPORTED_MODULE_2___default()))`
  color: #000000;
  font-size: 18px;
  font-weight: 600;
`;
const Header = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavContent, {
                href: "/team/men",
                children: "TEAM"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: "https://i.imgur.com/BAjHmEF.jpeg",
                alt: "로고",
                width: 71,
                height: 70
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavContent, {
                href: "/stat",
                children: "STATS"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ }),

/***/ 5871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);





const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  height: 240px;
  display: flex;
  flex-direction: column;
  background-color: #78a34d;
  background-position: calc(50% + 205px) top;
  background-image: url('https://www.kovo.co.kr/images/common/bg_sub3.jpg');
  background-repeat: no-repeat;

  @media (max-width: 768px) {
    height: 200px;
  }
`;
const SubTabBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  justify-content: center;
`;
const TabLink = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default()((next_link__WEBPACK_IMPORTED_MODULE_2___default()))`
  color: ${({ path  })=>path === "true" ? "#fff" : "rgba(255, 255, 255, 0.5)"};
  font-size: 14px;
  font-weight: bold;
  padding: 14px;
`;
const TeamBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  align-items: center;
  width: 1200px;
  margin: 0 auto;
  height: 180px;
  font-size: 40px;
  font-weight: bold;
  color: #fff;

  @media (max-width: 1200px) {
    width: 100%;
    padding: 0 50px;
  }
  @media (max-width: 768px) {
    font-size: 28px;
    padding: 0 30px;
  }
`;
const SubNavgation = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const id = router.query.id;
    const handleName = (router)=>{
        switch(router){
            case "men":
                return "남자부";
            case "women":
                return "여자부";
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SubTabBox, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabLink, {
                        href: "/team/men",
                        path: `${id === "men"}`,
                        children: "남자부"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabLink, {
                        href: "/team/women",
                        path: `${id === "women"}`,
                        children: "여자부"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamBox, {
                children: handleName(id)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubNavgation);


/***/ }),

/***/ 7704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* eslint-disable @next/next/no-img-element */ 


const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  display: flex;
  flex-direction: column;
`;
const CoachWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  padding: 20px 0 30px 10px;
  border-bottom: 1px solid #d1d5e0;
  gap: 35px;
  @media (max-width: 768px) {
    gap: 20px;
    padding: 20px 0 20px 10px;
  }
`;
const Title = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-weight: bold;
  font-size: 16px;
  color: #0e76bc;
  padding-bottom: 10px;
  border-bottom: 2px solid #1a2b64;
  @media (max-width: 768px) {
    font-size: 14px;
  }
`;
const CoachNameWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  flex-direction: column;
  gap: 18px;
  justify-content: center;

  @media (max-width: 768px) {
    gap: 12px;
  }

  span {
    font-size: 14px;
    font-weight: 700;
    color: #1a2b64;

    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
  p {
    font-size: 14px;
    margin: 0;
    font-weight: 700;
    color: #767676;
    line-height: 20px;

    @media (max-width: 768px) {
      font-size: 12px;
      line-height: 18px;
    }
  }
`;
const CoachImage = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  width: 180px;
  height: 200px;
  border: 1px solid #e0e0e0;
  @media (max-width: 768px) {
    width: 140px;
    height: 160px;
  }
`;
const TeamCoach = ({ coach  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                children: "감독"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CoachWrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CoachImage, {
                        src: coach && coach.profile_image,
                        alt: "프로필사진"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CoachNameWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: coach?.name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                children: [
                                    "생년월일 : ",
                                    coach?.birth,
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    " 포지션 : ",
                                    coach?.position_name
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamCoach);


/***/ }),

/***/ 8700:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ TeamComboBox),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _TeamHeader_TeamHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1208);
/* harmony import */ var _TeamCoach_TeamCoach__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7704);
/* harmony import */ var _TeamIntroduction_TeamIntroduction__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2495);
/* harmony import */ var _TeamPlayers_TeamPlayers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(92);
/* harmony import */ var _TeamRecords_TeamRecords__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4055);
/* harmony import */ var _TeamReview_TeamReview__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2937);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_2__, _TeamRecords_TeamRecords__WEBPACK_IMPORTED_MODULE_9__, _TeamReview_TeamReview__WEBPACK_IMPORTED_MODULE_10__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_2__, _TeamRecords_TeamRecords__WEBPACK_IMPORTED_MODULE_9__, _TeamReview_TeamReview__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  height: 100%;
`;
const TeamWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 1200px;
  margin: 50px auto 0;
  display: flex;
  flex-direction: column;
  gap: 20px;
  @media (max-width: 1200px) {
    width: 100%;
    padding: 0 50px;
  }
  @media (max-width: 768px) {
    width: 100%;
    padding: 0 30px;
  }
`;
const TeamComboBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().select)`
  width: 210px;
  height: 32px;
  padding-left: 10px;
  text-align: left;
  font-size: 14px;
  color: #999;
  cursor: pointer;
  border: 1px solid #e0e0e0;
  background: #f8f8f8
    url('https://www.kovo.co.kr/images/bg/bg_select_table.png') right center
    no-repeat;

  @media (max-width: 768px) {
    width: 170px;
    height: 28px;
    font-size: 12px;
  }
`;
const TeamInfoBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
`;
const TeamDetails = ({ team , coach , player , isBlue =false  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const page = router.pathname.split("/");
    const id = router.query.id;
    const [teamList, setTeamList] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_2__/* .TokenClient.get */ .u.get("/team", {
            params: {
                gender: id === "men" ? true : false
            }
        }).then((response)=>{
            console.log(response.data);
            console.log(response.status);
            if (response.status === 200) {
                setTeamList(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        id
    ]);
    const handleChange = (e)=>{
        router.push({
            pathname: window.location.pathname,
            query: {
                team_id: e.target.value
            }
        });
    };
    const renderContentByPage = (page)=>({
            introduction: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamIntroduction_TeamIntroduction__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                team: team
            }),
            coach: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamCoach_TeamCoach__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                coach: coach
            }),
            players: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_TeamPlayers__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                player: player,
                team: team
            }),
            record: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecords_TeamRecords__WEBPACK_IMPORTED_MODULE_9__/* .TeamRecords */ .A, {
                team: team
            }),
            review: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamReview_TeamReview__WEBPACK_IMPORTED_MODULE_10__/* .TeamReview */ .V, {})
        })[page] || /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamWrapper, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamComboBox, {
                    onChange: handleChange,
                    value: team?.id,
                    children: teamList.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: item.id,
                            children: item.name
                        }, item.id))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamInfoBox, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamHeader_TeamHeader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        team: team,
                        isBlue: isBlue
                    })
                }),
                renderContentByPage(page[3])
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export TeamIntroduction */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* eslint-disable @next/next/no-img-element */ 


const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  height: 100%;
`;
const TeamWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  display: flex;
  align-items: center;
  max-width: 960px;
  height: 246px;
  border-radius: 3px;
  border: 1px solid #e0e0e0;
  gap: 50px;

  @media (max-width: 768px) {
    height: 230px;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 20px;
  }
`;
const TeamTitleWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  flex-direction: column;
  padding: 24px 0 50px;
  height: 100%;
  gap: 23px;
  justify-content: center;

  @media (max-width: 768px) {
    padding: 0;
    gap: 16px;
    height: unset;
    align-items: center;
    justify-content: flex-start;
  }
`;
const TeamTitle = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-size: 24px;
  font-weight: bold;
  color: #253032;
  @media (max-width: 768px) {
    font-size: 20px;
  }
`;
const TeamCoach = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-size: 14px;
  font-weight: bold;
  color: #767676;
  @media (max-width: 768px) {
    font-size: 12px;
  }
`;
const TeamSubTitle = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  margin-top: 20px;
  font-size: 16px;
  color: #0e76bc;
  font-weight: bold;
  @media (max-width: 768px) {
    font-size: 14px;
  }
`;
const PerformanceWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  margin: 10px 0 100px 0;
  width: 100%;
  max-width: 960px;
  border-top: 2px solid #1a2b64;
  overflow-x: auto;

  table {
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    table-layout: fixed;
  }

  th {
    font-size: 14px;
    padding: 15px 0;
    color: #1a2b64;
    background: #f6f7f8;
    border-bottom: 1px solid #e0dfe1;

    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
  td {
    font-size: 14px;
    padding: 15px 0;
    border-bottom: 1px solid #e0dfe1;
    text-align: center;
    color: #767676;
    font-weight: 700px;

    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
`;
const Logo = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  width: 180px;
  height: 135px;
  margin-left: 25px;

  @media (max-width: 768px) {
    width: 125px;
    height: 95px;
    margin-left: 0;
  }
`;
const TeamIntroduction = ({ team  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamWrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Logo, {
                        src: team && team.team_logo,
                        alt: "로고"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamTitleWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamTitle, {
                                children: team && team.name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamCoach, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        style: {
                                            color: "#253032"
                                        },
                                        children: "코치"
                                    }),
                                    " :",
                                    team && team.coach
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamSubTitle, {
                children: "역대 성적"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PerformanceWrapper, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        style: {
                                            width: "130px"
                                        },
                                        children: "번호"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        style: {
                                            width: "320px"
                                        },
                                        children: "대회명"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        style: {
                                            width: "130px"
                                        },
                                        children: "성적"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        style: {
                                            width: "130px"
                                        },
                                        children: "전적"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        style: {
                                            width: "250px"
                                        },
                                        children: "대회 기간"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: team && team.performance.map((data, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            children: data.id
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            children: data.competition_name
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            children: data.results
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                            children: [
                                                data.win_counts,
                                                "승 ",
                                                data.lose_counts,
                                                "패"
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            children: data.start_date === data.end_date ? `${data.start_date}` : `${data.start_date} ~ ${data.end_date}`
                                        })
                                    ]
                                }, idx))
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamIntroduction);


/***/ }),

/***/ 6686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ PhotoSwiper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3630);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper_swiper_min_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8722);
/* harmony import */ var swiper_swiper_min_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_swiper_min_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2770);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_swiper_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9076);
/* harmony import */ var swiper_swiper_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_swiper_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_components_navigation_navigation_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9761);
/* harmony import */ var swiper_components_navigation_navigation_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_components_navigation_navigation_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swiper_components_pagination_pagination_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7199);
/* harmony import */ var swiper_components_pagination_pagination_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(swiper_components_pagination_pagination_scss__WEBPACK_IMPORTED_MODULE_8__);









const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  height: 365px;
  border: 1px solid #e0e0e0;
  border-radius: 3px;
  margin-top: 15px;
`;
const ImageBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
`;
const ImageBlock = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  height: 365px;

  @media (max-width: 768px) {
    height: 265px;
  }
`;
swiper__WEBPACK_IMPORTED_MODULE_5___default().use([
    swiper__WEBPACK_IMPORTED_MODULE_5__.Navigation,
    swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination,
    swiper__WEBPACK_IMPORTED_MODULE_5__.Autoplay
]);
const PhotoSwiper = ({ images  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
            navigation: true,
            style: {
                width: "100%",
                height: "100%"
            },
            spaceBetween: 50,
            pagination: {
                clickable: true
            },
            autoplay: {
                delay: 5000
            },
            loop: true,
            children: images && images.map((item)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                    style: {
                        width: "100%",
                        height: "100%"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImageBox, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImageBlock, {
                            src: item.image_url,
                            alt: `${item.id}`
                        })
                    })
                }, item.id);
            })
        })
    });
};


/***/ }),

/***/ 9210:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ RecordTitle),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6107);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _PhotoSwiper_PhotoSwiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6686);
/* harmony import */ var _PlayerJob_PlayerJob__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4366);
/* harmony import */ var _RecordTabs_RecordTabs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_2__]);
lib_Axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  max-width: 960px;
`;
const ProfileBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  flex-direction: column;
  width: 100%;
  border: 1px solid #e0e0e0;
  border-radius: 3px;
  margin-top: 30px;
`;
const ProfileImage = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  width: 507px;
  height: 498px;
  @media (max-width: 768px) {
    width: 400px;
    height: 400px;
  }
  @media (max-width: 600px) {
    width: 100%;
    height: 100%;
  }
`;
const PlayerProfileWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 453px;
  height: 498px;
  flex-direction: column;
  padding-top: 86px;

  @media (max-width: 600px) {
    padding-top: 0px;
    width: 100%;
    height: 100%;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
`;
const PlyaerNumber = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  color: #253032;
  font-size: 24px;
  font-weight: bold;

  @media (max-width: 768px) {
    font-size: 20px;
    text-align: center;
  }
`;
const PlayerName = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  color: #253032;
  font-size: 28px;
  padding-top: 10px;
  font-weight: bold;
  @media (max-width: 768px) {
    font-size: 22px;
    text-align: center;
  }
`;
const ProfileContent = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 351px;
  margin-top: 33px;
  padding-top: 34px;
  border-top: 1px solid #e0e0e0;

  @media (max-width: 980px) {
    width: unset;
    margin-right: 20px;
  }
  @media (max-width: 600px) {
    border: none;
    text-align: center;
    margin-top: 0px;
    margin-right: 0px;
    padding: 10px 0 20px 0;
  }
`;
const ProfileBlock = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  align-items: center;
  gap: 15px;

  @media (max-width: 980px) {
    flex-direction: column;
    gap: 6px;
    margin-top: 8px;
  }
  h4 {
    color: #253032;
    font-weight: bold;
    font-size: 14px;
    margin: 3px;
    width: 60px;

    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
  span {
    color: #767676;
    font-size: 14px;
    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
`;
const RecordTable = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().table)`
  width: 100%;
  border-spacing: 0;
  table-layout: fixed;

  td {
    height: 50px;
    font-size: 14px;
    color: #767676;
    text-align: center;
    border-top: 1px solid #e0e0e0;

    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
  td + td {
    border-left: 1px solid #e0e0e0;
  }
`;
const TableHeader = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().thead)`
  th {
    font-size: 14px;
    font-weight: 700;
    color: #1a2b64;
    background-color: #f6f7f8;
    height: 50px;
    text-align: center;
    border-top: 1px solid #e0e0e0;
    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
  th + th {
    border-left: 1px solid #e0e0e0;
  }
`;
const TableBody = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().tbody)`
  th {
    height: 50px;
    font-size: 14px;
    color: #253032;
    text-align: center;
    border-top: 1px solid #e0e0e0;
    border-right: 1px solid #e0e0e0;
    background-color: #ffffff;
    @media (max-width: 768px) {
      font-size: 10px;
    }
  }
`;
const RecordTitle = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  margin-top: 20px;
  font-size: 16px;
  color: #0e76bc;
  font-weight: bold;

  @media (max-width: 768px) {
    font-size: 14px;
  }
`;
const RecordBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  height: 247px;
  border: 1px solid #e0e0e0;
  margin-top: 15px;
`;
const FlexBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  gap: 30px;
  @media (max-width: 600px) {
    flex-direction: column;
  }
`;
const PlayerDetails = ({ team_id , player_id  })=>{
    // eslint-disable-next-line @typescript-eslint/ban-types
    const [playerData, setPlayerData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_2__/* .TokenClient.get */ .u.get(`/team/player/${player_id}`, {
            params: {
                team_id: team_id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setPlayerData(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        team_id,
        player_id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ProfileBox, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FlexBox, {
                        style: {
                            display: "flex",
                            gap: "30px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ProfileImage, {
                                src: playerData?.user.profile_image
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PlayerProfileWrapper, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PlyaerNumber, {
                                        children: [
                                            "NO.",
                                            playerData?.user.number,
                                            " ",
                                            playerData?.user.position === null ? "-" : playerData?.user.position
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PlayerName, {
                                        children: playerData?.user.name
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ProfileContent, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ProfileBlock, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                        children: "생년월일"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: playerData?.user.birth
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ProfileBlock, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                        children: "신장/체중"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        children: [
                                                            playerData?.user.height === null ? "-" : playerData?.user.height,
                                                            "cm /",
                                                            " ",
                                                            playerData?.user.weight === null ? "-" : playerData?.user.weight,
                                                            "kg"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(RecordTable, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TableHeader, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            scope: "col",
                                            children: "구분"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            scope: "col",
                                            children: "득점"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            scope: "col",
                                            children: "공격"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            scope: "col",
                                            children: "서브"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            scope: "col",
                                            children: "블로킹"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            scope: "col",
                                            children: "수비"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TableBody, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "row",
                                                children: "종합기록"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.score_rank.total_count
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.attack_rank.total_count
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.serve_rank.total_count
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.block_rank.total_count
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.receive_rank.total_count
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "row",
                                                children: "전체순위"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.score_rank.rank
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.attack_rank.rank
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.serve_rank.rank
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.block_rank.rank
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                children: playerData?.player_record.receive_rank.rank
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RecordTitle, {
                children: "기록 상세 (연도)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RecordBox, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RecordTabs_RecordTabs__WEBPACK_IMPORTED_MODULE_6__/* .RecordTabs */ ._, {
                    data: playerData?.detail_record
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RecordTitle, {
                children: "포토갤러리"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PhotoSwiper_PhotoSwiper__WEBPACK_IMPORTED_MODULE_4__/* .PhotoSwiper */ .i, {
                images: playerData?.photo_gallery_urls
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RecordTitle, {
                children: "주요 경력"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PlayerJob_PlayerJob__WEBPACK_IMPORTED_MODULE_5__/* .PlayerJob */ .D, {
                data: playerData?.job
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlayerDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ PlayerJob)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);


const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  display: flex;
  height: 160px;
  border: 1px solid #e0e0e0;
  margin-top: 15px;
  margin-bottom: 100px;
`;
const Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 18px 22px;

  &:first-of-type {
    border-right: 1px solid #e0e0e0;
  }
  &:last-of-type {
    border-left: 1px solid #e0e0e0;
  }

  @media (max-width: 768px) {
    padding: 18px 14px;
    text-align: center;
  }
`;
const Title = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-size: 14px;
  margin-bottom: 12px;
  font-weight: bold;
  color: #1a2b64;
  @media (max-width: 768px) {
    font-size: 12px;
  }
`;
const Text = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-size: 13px;
  color: rgb(118, 118, 118);
  font-weight: bold;

  @media (max-width: 768px) {
    font-size: 10px;
  }
`;
const PlayerJob = ({ data  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                        children: "역대 시상내역"
                    }),
                    data && data.prize.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Text, {
                            children: [
                                "- ",
                                item.prize_name
                            ]
                        }, item.id))
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                        children: "트리플 크라운"
                    }),
                    data && data.triple_crown.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Text, {
                            children: [
                                "- ",
                                item.created_at,
                                " 후위 ",
                                item.back_attack_count,
                                "개, 서브",
                                " ",
                                item.serve_count,
                                "개, 블로킹 ",
                                item.block_count,
                                "개"
                            ]
                        }, item.id))
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                        children: "기준기록"
                    }),
                    data && data.reference_record.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Text, {
                            children: [
                                "- ",
                                item.created_at,
                                " ",
                                item.record_name,
                                " "
                            ]
                        }, item.id))
                ]
            })
        ]
    });
};


/***/ }),

/***/ 68:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "_": () => (/* binding */ RecordTabs)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@emotion/styled"
var styled_ = __webpack_require__(1480);
var styled_default = /*#__PURE__*/__webpack_require__.n(styled_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Team/TeamDetails/TeamPlayers/PlayerDetails/RecordTabs/RecordTabAttack/RecordTabAttack.tsx


const PlayerStat = (styled_default()).div`
  width: 411px;
  border-left: 1px solid #e0e0e0;
  margin: 0;
  text-align: center;

  dl {
    width: 33.33%;
    float: left;
    border-right: 1px solid #e0e0e0;
    border-bottom: 1px solid #e0e0e0;
    box-sizing: border-box;
    margin: 0;

    &:nth-child(3) {
      border-right: none;
    }
    &:nth-child(6) {
      border-right: none;
    }

    dt {
      line-height: 61px;
      font-weight: 700;
      height: 62px;
      font-size: 14px;
      color: #1a2b64;
      background-color: #f6f7f8;
      border-bottom: 1px solid #e0e0e0;
      margin: 0;

      @media (max-width: 768px) {
        font-size: 10px;
      }
    }

    dd {
      height: 60px;
      line-height: 61px;
      font-size: 14px;
      margin: 0;
      font-weight: 500;

      @media (max-width: 768px) {
        font-size: 10px;
      }
    }
  }
`;
const RecordTabAttack = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(PlayerStat, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "공격 시도"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.attack
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "공격 성공"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.attack_success
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "범실"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.attack_miss
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "상대 블록"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.blocking_shut_out
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "성공율"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dd", {
                        children: [
                            data?.accuracy,
                            "%"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "점유율"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dd", {
                        children: [
                            data?.possession,
                            "%"
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Team/TeamDetails/TeamPlayers/PlayerDetails/RecordTabs/RecordTabBlock/RecordTabBlock.tsx


const RecordTabBlock = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(PlayerStat, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "블로킹 성공"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.block_success
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "유효 블로킹"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.block
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "실패"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.block_fail
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "범실"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.block_miss
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "점유율"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dd", {
                        children: [
                            data?.possession,
                            "%"
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Team/TeamDetails/TeamPlayers/PlayerDetails/RecordTabs/RecordTabDig/RecordTabDig.tsx


const RecordTabDig = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(PlayerStat, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "디그 시도"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.dig
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "디그 정확"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.dig_success
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "디그 실패"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.dig_fail
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "점유율"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dd", {
                        children: [
                            data?.possession,
                            "%"
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Team/TeamDetails/TeamPlayers/PlayerDetails/RecordTabs/RecordTabReceive/RecordTabReceive.tsx


const RecordTabReceive = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(PlayerStat, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "리시브 시도"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.receive
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "리시브 정확"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.receive_success
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "리시브 실패"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.receive_miss
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "점유율"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dd", {
                        children: [
                            data?.possession,
                            "%"
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Team/TeamDetails/TeamPlayers/PlayerDetails/RecordTabs/RecordTabServe/RecordTabServe.tsx


const RecordTabServe = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(PlayerStat, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "서브 시도"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.serve_count
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "서브 성공"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.serve_success
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "범실"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("dd", {
                        children: data?.serve_miss
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dl", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("dt", {
                        children: "점유율"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("dd", {
                        children: [
                            data?.possession,
                            "%"
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Team/TeamDetails/TeamPlayers/PlayerDetails/RecordTabs/RecordTabs.tsx








const AttackTypeWrapper = (styled_default()).div`
  display: flex;
  flex-direction: column;
  width: 138px;
  height: 100%;
`;
const AttackTypeBox = (styled_default()).div`
  width: 138px;
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  color: ${({ isActive  })=>isActive ? "#fff" : "#333"};
  font-weight: bold;
  font-size: 15px;
  background-color: ${({ isActive  })=>isActive ? "#0e76bc" : "#f6f7f8"};
  border-right: 1px solid #e0e0e0;
  border-top: 1px solid #e0e0e0;

  @media (max-width: 768px) {
    font-size: 13px;
  }
  &:first-of-type {
    border-top: none;
  }
`;
const Box = (styled_default()).div`
  width: 411px;

  @media (max-width: 768px) {
    width: 200px;
  }
  @media (max-width: 550px) {
    width: 50px;
  }
  @media (max-width: 470px) {
    width: 0px;
  }
`;
const RecordTabs = ({ data  })=>{
    const [currentTab, clickTab] = (0,external_react_.useState)(0);
    const menuArr = [
        {
            name: "공격",
            content: /*#__PURE__*/ jsx_runtime_.jsx(RecordTabAttack, {
                data: data?.attack
            })
        },
        {
            name: "블로킹",
            content: /*#__PURE__*/ jsx_runtime_.jsx(RecordTabBlock, {
                data: data?.block
            })
        },
        {
            name: "서브",
            content: /*#__PURE__*/ jsx_runtime_.jsx(RecordTabServe, {
                data: data?.serve
            })
        },
        {
            name: "서브 리시브",
            content: /*#__PURE__*/ jsx_runtime_.jsx(RecordTabReceive, {
                data: data?.serve_receive
            })
        },
        {
            name: "디그",
            content: /*#__PURE__*/ jsx_runtime_.jsx(RecordTabDig, {
                data: data?.dig
            })
        }
    ];
    const selectMenuHandler = (index)=>{
        clickTab(index);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(AttackTypeWrapper, {
                children: menuArr.map((el, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(AttackTypeBox, {
                        isActive: idx === currentTab,
                        onClick: ()=>selectMenuHandler(idx),
                        children: el.name
                    }, idx))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box, {}),
            menuArr[currentTab].content
        ]
    });
};


/***/ }),

/***/ 92:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* eslint-disable @next/next/no-img-element */ 



const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  max-width: 960px;
  display: flex;
  flex-direction: column;
`;
const CoachWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  padding: 20px 0 30px 10px;
  border-bottom: 1px solid #d1d5e0;
  gap: 35px;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    gap: 20px;
  }
`;
const Title = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-weight: bold;
  margin-top: 50px;
  font-size: 16px;
  color: #0e76bc;
  padding-bottom: 10px;
  border-bottom: 2px solid #1a2b64;

  &:first-of-type {
    margin-top: 0px;
  }
  @media (max-width: 768px) {
    margin-top: 30px;
    font-size: 14px;
  }
`;
const PlayerNameWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  flex-direction: column;
  gap: 18px;
  justify-content: center;

  p {
    font-size: 14px;
    margin: 0;
    font-weight: 700;
    color: #767676;
    margin-top: 10px;
    text-align: center;
    @media (max-width: 768px) {
      font-size: 12px;
    }
  }

  @media (max-width: 768px) {
    gap: 10px;
  }
`;
const PlayerPosTab = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 35px;
  @media (max-width: 768px) {
    gap: 25px;
  }
`;
const PlayerPosition = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-size: 15px;
  font-weight: ${({ isPosition  })=>isPosition ? "bold" : "medium"};
  color: ${({ isPosition  })=>isPosition ? "#0e76bc" : "#767676"};

  @media (max-width: 768px) {
    font-size: 13px;
  }
`;
const PlayerImg = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  width: 180px;
  height: 200px;
  border: 1px solid #e0e0e0;

  @media (max-width: 768px) {
    width: 120px;
    height: 130px;
  }
`;
const TeamPlayers = ({ player , team  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const queryId = router.query.id;
    const [position, setPosition] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("전체");
    const PosHeaderList = [
        "전체",
        "아웃사이드 히터",
        "아포짓 스파이커",
        "미들 블로커",
        "세터",
        "리베로"
    ];
    const PosList = [
        "아웃사이드 히터",
        "아포짓 스파이커",
        "미들 블로커",
        "세터",
        "리베로"
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PlayerPosTab, {
                children: PosHeaderList.map((pos, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PlayerPosition, {
                        onClick: ()=>setPosition(pos),
                        isPosition: pos === position,
                        children: pos
                    }, idx))
            }),
            position !== "전체" ? PosList.filter((data)=>data === position).map((pos, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                            children: pos
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CoachWrapper, {
                            children: player?.filter((player)=>player.position_name === pos).map((player)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PlayerNameWrapper, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PlayerImg, {
                                            src: player.profile_image,
                                            alt: "프로필사진",
                                            onClick: ()=>router.push({
                                                    pathname: `/team/${queryId}/playerInfo`,
                                                    query: {
                                                        team_id: team && team.id,
                                                        player: player && player.id
                                                    }
                                                })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            children: [
                                                "NO.",
                                                player.number,
                                                " ",
                                                player.name,
                                                "(",
                                                player.position_code,
                                                ")"
                                            ]
                                        })
                                    ]
                                }, player.id))
                        })
                    ]
                }, idx)) : PosList.map((pos, idx)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                            children: pos
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CoachWrapper, {
                            children: player?.filter((player)=>player.position_name === pos).map((player)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(PlayerNameWrapper, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PlayerImg, {
                                            src: player.profile_image,
                                            alt: "프로필사진",
                                            onClick: ()=>router.push({
                                                    pathname: `/team/${queryId}/playerInfo`,
                                                    query: {
                                                        team_id: team && team.id,
                                                        player: player && player.id
                                                    }
                                                }, undefined, {
                                                    shallow: true
                                                })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            children: [
                                                "NO.",
                                                player.number,
                                                " ",
                                                player.name,
                                                "(",
                                                player.position_code,
                                                ")"
                                            ]
                                        })
                                    ]
                                }, player.id))
                        })
                    ]
                }, idx))
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamPlayers);


/***/ }),

/***/ 5377:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TeamRecordItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9210);
/* harmony import */ var _TeamRecords__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const TeamRecordItem = ()=>{
    const [attackData, setAttackData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const id = router.query.team_id;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_1__/* .TokenClient.get */ .u.get("/team/record/attack", {
            params: {
                team_id: id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setAttackData(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__/* .RecordTitle */ .U, {
                children: "공격 기록"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecords__WEBPACK_IMPORTED_MODULE_5__/* .PerformanceWrapper */ .F, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "경기수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "세트수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "공격 시도"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "공격 성공"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "범실"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "상대 블로킹"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: attackData?.match_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: attackData?.set_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: attackData?.attack
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: attackData?.attack_success
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: attackData?.attack_miss
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: attackData?.blocking_shut_out
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ TeamRecordBlock)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9210);
/* harmony import */ var _TeamRecords__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const TeamRecordBlock = ()=>{
    const [blockData, setBlockData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const id = router.query.team_id;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_1__/* .TokenClient.get */ .u.get("/team/record/block", {
            params: {
                team_id: id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setBlockData(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__/* .RecordTitle */ .U, {
                children: "블로킹 기록"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecords__WEBPACK_IMPORTED_MODULE_5__/* .PerformanceWrapper */ .F, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "경기수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "세트수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "블로킹 성공"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "유효 블로킹"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "범실"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "실패"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: blockData?.match_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: blockData?.set_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: blockData?.block_success
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: blockData?.block
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: blockData?.block_miss
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: blockData?.block_fail
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8895:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ TeamRecordDig)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9210);
/* harmony import */ var _TeamRecords__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const TeamRecordDig = ()=>{
    const [digData, setDigData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const id = router.query.team_id;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_1__/* .TokenClient.get */ .u.get("/team/record/dig", {
            params: {
                team_id: id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setDigData(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__/* .RecordTitle */ .U, {
                children: "디그 기록"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecords__WEBPACK_IMPORTED_MODULE_5__/* .PerformanceWrapper */ .F, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "경기수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "세트수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "디그 시도"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "디그 성공"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "디그 실패"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: digData?.match_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: digData?.set_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: digData?.dig
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: digData?.dig_success
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: digData?.dig_fail
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9811:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ TeamRecordReceive)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9210);
/* harmony import */ var _TeamRecords__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const TeamRecordReceive = ()=>{
    const [receiveData, setReceiveData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const id = router.query.team_id;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_1__/* .TokenClient.get */ .u.get("/team/record/serve_receive", {
            params: {
                team_id: id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setReceiveData(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__/* .RecordTitle */ .U, {
                children: "리시브 기록"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecords__WEBPACK_IMPORTED_MODULE_5__/* .PerformanceWrapper */ .F, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "경기수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "세트수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "리시브 시도"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "리시브 성공"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "리시브 실패"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: receiveData?.match_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: receiveData?.set_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: receiveData?.receive
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: receiveData?.receive_success
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: receiveData?.receive_miss
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6931:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ TeamRecordServe)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9210);
/* harmony import */ var _TeamRecords__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_1__, _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__, _TeamRecords__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const TeamRecordServe = ()=>{
    const [serveData, setServeData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const id = router.query.team_id;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_1__/* .TokenClient.get */ .u.get("/team/record/serve", {
            params: {
                team_id: id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setServeData(response.data.data);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        id
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_4__/* .RecordTitle */ .U, {
                children: "서브 기록"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecords__WEBPACK_IMPORTED_MODULE_5__/* .PerformanceWrapper */ .F, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "경기수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "세트수"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "서브 시도"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "서브 득점"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        children: "서브 범실"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: serveData?.match_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: serveData?.set_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: serveData?.serve_count
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: serveData?.serve_success
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: serveData?.serve_miss
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4055:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ TeamRecords),
/* harmony export */   "F": () => (/* binding */ PerformanceWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9210);
/* harmony import */ var _TeamRecordAttack_TeamRecordAttack__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5377);
/* harmony import */ var _TeamRecordBlock_TeamRecordBlock__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7372);
/* harmony import */ var _TeamRecordDig_TeamRecordDig__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8895);
/* harmony import */ var _TeamRecordReceive_TeamRecordReceive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9811);
/* harmony import */ var _TeamRecordServe_TeamRecordServe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6931);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_3__, _TeamRecordAttack_TeamRecordAttack__WEBPACK_IMPORTED_MODULE_4__, _TeamRecordBlock_TeamRecordBlock__WEBPACK_IMPORTED_MODULE_5__, _TeamRecordDig_TeamRecordDig__WEBPACK_IMPORTED_MODULE_6__, _TeamRecordReceive_TeamRecordReceive__WEBPACK_IMPORTED_MODULE_7__, _TeamRecordServe_TeamRecordServe__WEBPACK_IMPORTED_MODULE_8__]);
([_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_3__, _TeamRecordAttack_TeamRecordAttack__WEBPACK_IMPORTED_MODULE_4__, _TeamRecordBlock_TeamRecordBlock__WEBPACK_IMPORTED_MODULE_5__, _TeamRecordDig_TeamRecordDig__WEBPACK_IMPORTED_MODULE_6__, _TeamRecordReceive_TeamRecordReceive__WEBPACK_IMPORTED_MODULE_7__, _TeamRecordServe_TeamRecordServe__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const PerformanceWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  margin: 10px 0 100px 0;
  width: 100%;
  max-width: 960px;
  border-top: 2px solid #1a2b64;

  @media (max-width: 768px) {
    overflow-x: auto;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    table-layout: fixed;
  }

  th {
    font-size: 14px;
    padding: 15px 0;
    color: #1a2b64;
    background: #f6f7f8;
    border-bottom: 1px solid #e0dfe1;

    @media (max-width: 768px) {
      width: 73.33px;
      font-size: 12px;
    }
  }
  td {
    font-size: 14px;
    padding: 15px 0;
    border-bottom: 1px solid #e0dfe1;
    text-align: center;
    color: #767676;
    font-weight: 700px;

    @media (max-width: 768px) {
      font-size: 12px;
    }
  }
`;
const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  max-width: 960px;
  display: flex;
  flex-direction: column;
`;
const TeamBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 100%;
  align-items: center;
  height: 140px;
  border: 1px solid #e0e0e0;
  border-radius: 3px;
  padding-left: 30px;
  @media (max-width: 768px) {
    padding: 0 20px;
    justify-content: center;
  }
  @media (max-width: 500px) {
    gap: 40px;
  }
`;
const TeamLogo = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  width: 150px;
  height: 112px;

  @media (max-width: 768px) {
    width: 80px;
    height: 72px;
  }
`;
const TeamNameBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 300px;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #253032;
  font-weight: bold;
  font-size: 18px;

  @media (max-width: 768px) {
    width: 200px;
    font-size: 16px;
  }
  @media (max-width: 500px) {
    width: unset;
  }
`;
const ScoreBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  margin-left: 100px;
  align-items: center;
  height: 100%;
  display: flex;
  gap: 10px;

  @media (max-width: 1050px) {
    margin-left: 70px;
  }
  @media (max-width: 980px) {
    margin-left: 50px;
  }
  @media (max-width: 925px) {
    margin-left: 30px;
  }
  @media (max-width: 768px) {
    margin-left: 0px;
  }
`;
const WinCircle = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  background-color: #0e76bc;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 36px;
  height: 36px;
  color: #fff;
  font-size: 14px;
  font-weight: bold;
  border-radius: 100%;
  @media (max-width: 768px) {
    font-size: 12px;
    width: 30px;
    height: 30px;
  }
`;
const LoseCircle = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  background-color: #767676;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 36px;
  height: 36px;
  color: #fff;
  font-size: 14px;
  font-weight: bold;
  border-radius: 100%;

  @media (max-width: 768px) {
    margin-left: 25px;
    font-size: 12px;
    width: 30px;
    height: 30px;
  }
  @media (max-width: 500px) {
    margin-left: 0;
  }
`;
const Text = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  color: #1a2b64;
  font-size: 14px;
  font-weight: bold;
  @media (max-width: 768px) {
    font-size: 12px;
  }
`;
const MenuBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  height: 50px;
  margin-top: 15px;
  @media (max-width: 768px) {
    height: 40px;
  }
`;
const MenuBlock = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  background: ${({ isActive  })=>isActive ? "#0e76bc" : "#e5e6e7"};
  height: 50px;
  font-size: 15px;
  border-right: 1px solid #e0e0e0;
  color: ${({ isActive  })=>isActive ? "#fff" : "#333"};

  &:last-child {
    border: 0;
  }

  @media (max-width: 768px) {
    height: 40px;
    font-size: 13px;
  }
`;
const Flexbox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  align-items: center;

  @media (max-width: 500px) {
    flex-direction: column;
    gap: 5px;
  }
`;
const TeamRecords = ({ team  })=>{
    const [currentTab, clickTab] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const menuArr = [
        {
            name: "공격",
            content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecordAttack_TeamRecordAttack__WEBPACK_IMPORTED_MODULE_4__/* .TeamRecordItem */ .Z, {})
        },
        {
            name: "블로킹",
            content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecordBlock_TeamRecordBlock__WEBPACK_IMPORTED_MODULE_5__/* .TeamRecordBlock */ .g, {})
        },
        {
            name: "서브",
            content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecordServe_TeamRecordServe__WEBPACK_IMPORTED_MODULE_8__/* .TeamRecordServe */ .Q, {})
        },
        {
            name: "리시브",
            content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecordReceive_TeamRecordReceive__WEBPACK_IMPORTED_MODULE_7__/* .TeamRecordReceive */ .I, {})
        },
        {
            name: "디그",
            content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamRecordDig_TeamRecordDig__WEBPACK_IMPORTED_MODULE_6__/* .TeamRecordDig */ .i, {})
        }
    ];
    const selectMenuHandler = (index)=>{
        clickTab(index);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamBox, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Flexbox, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamLogo, {
                                src: team?.team_logo,
                                alt: "팀 로고"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamNameBox, {
                                children: team?.name
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ScoreBox, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(WinCircle, {
                                children: "승"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Text, {
                                children: team?.team_total_record?.total_win_count
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ScoreBox, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoseCircle, {
                                children: "패"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Text, {
                                children: team?.team_total_record?.total_lose_count
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_3__/* .RecordTitle */ .U, {
                children: "팀 기록"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuBox, {
                children: menuArr.map((el, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuBlock, {
                        isActive: idx === currentTab,
                        onClick: ()=>selectMenuHandler(idx),
                        children: el.name
                    }, idx))
            }),
            menuArr[currentTab].content
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2937:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ TeamReview)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lib_Axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6107);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _TeamDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8700);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([lib_Axios__WEBPACK_IMPORTED_MODULE_2__, _TeamDetails__WEBPACK_IMPORTED_MODULE_5__]);
([lib_Axios__WEBPACK_IMPORTED_MODULE_2__, _TeamDetails__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  max-width: 960px;
  display: flex;
  flex-direction: column;
`;
const ReviewHeader = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  height: 80px;
  background: #f9f9f9;
  border: 1px solid #e0e0e0;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
`;
const Title = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  font-size: 18px;
  color: #0e76bc;
  font-weight: bold;

  @media (max-width: 768px) {
    font-size: 14px;
  }
`;
const ReviewWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  padding: 36px 40px 35px 40px;
  color: #253032;
  border: 1px solid #e0e0e0;
  border-radius: 2px;
  font-size: 14px;
  font-weight: bold;
  white-space: pre-wrap;
  margin: 10px 0 100px 0;

  @media (max-width: 768px) {
    font-size: 12px;
    padding: 26px 30px 25px 30px;
  }
`;
const TeamReview = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const teamId = router.query.team_id;
    const [id, setId] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    const [selectData, setSelectData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [historyData, setHistoryData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        lib_Axios__WEBPACK_IMPORTED_MODULE_2__/* .TokenClient.get */ .u.get(`/team/history/${teamId}`, {
            params: {
                content_id: id
            }
        }).then((response)=>{
            console.log(response.data.data);
            console.log(response.status);
            if (response.status === 200) {
                setSelectData(response.data.data.history_list);
                setHistoryData(response.data.data.history_detail);
            }
        }).catch((response)=>{
            console.log(response.data);
            console.log(response.status);
        });
    }, [
        teamId,
        id
    ]);
    const handleChange = (e)=>{
        setId(Number(e.target.value));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ReviewHeader, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                        children: historyData?.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TeamDetails__WEBPACK_IMPORTED_MODULE_5__/* .TeamComboBox */ .R, {
                        onChange: handleChange,
                        children: selectData?.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: item.id,
                                children: item.title
                            }, item.id))
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ReviewWrapper, {
                children: historyData?.content
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export getServerSideProps */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const TeamInfoButton = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().button)`
  flex: 1;
  height: 50px;
  text-align: center;
  font-size: 15px;
  outline: none;
  border: none;
  border-right: 1px solid #c4c6c8;

  &:last-child {
    border: none;
  }
  @media (max-width: 768px) {
    width: 63px;
    height: 35px;
    font-size: 10px;
  }
`;
const TeamHeader = ({ team , isBlue  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const currentPage = router.asPath.split("?");
    const queryId = router.query.id;
    const List = [
        {
            name: "구단소개",
            href: `/team/${queryId}/introduction`
        },
        {
            name: "코칭스태프",
            href: `/team/${queryId}/coach`
        },
        {
            name: "선수소개",
            href: `/team/${queryId}/players`
        },
        {
            name: "팀기록",
            href: `/team/${queryId}/record`
        },
        {
            name: "역사",
            href: `/team/${queryId}/review`
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            display: "flex",
            flexWrap: "wrap",
            width: "100%",
            maxWidth: "960px"
        },
        children: List.map((data, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamInfoButton, {
                style: {
                    backgroundColor: idx === 2 ? isBlue ? "#0e76bc" : "#e5e6e7" : data.href === currentPage[0] ? "#0e76bc" : "#e5e6e7",
                    color: idx === 2 ? isBlue ? "#fff" : "#333" : data.href === currentPage[0] ? "#fff" : "#333"
                },
                onClick: ()=>router.replace({
                        pathname: data.href,
                        query: {
                            team_id: team && team.id
                        }
                    }),
                children: data.name
            }, idx))
    });
};
async function getServerSideProps() {
    return {
        props: {}
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TeamHeader);


/***/ }),

/***/ 3517:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);



const Container = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 100%;
  height: 100%;
`;
const TeamWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  width: 1200px;
  margin: 50px auto 0;
  display: flex;
  flex-wrap: wrap;
  gap: 20px;

  @media (max-width: 1200px) {
    width: 100%;
    padding: 0 50px;
  }
  @media (max-width: 768px) {
    justify-content: center;
    width: 100%;
    padding: 0 30px;
    margin: 30px auto 0;
  }
`;
const TeamBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  align-items: center;
  width: 470px;
  height: 168px;
  border: 1px solid #e0e0e0;
  gap: 30px;

  @media (max-width: 768px) {
    align-items: flex-start;
    width: 315px;
    height: 140px;
    gap: 15px;
  }
`;
const LogoImage = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`
  margin-left: 15px;
  width: 195px;
  height: 146px;
  @media (max-width: 768px) {
    margin-top: 14px;
    width: 125px;
    height: 105px;
  }
`;
const TeamContentBox = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  width: 228px;
  height: 100%;
  flex-direction: column;

  @media (max-width: 768px) {
    width: 145px;
  }
`;
const TeamTitle = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  margin: 25px 0 11px 0;
  font-weight: bold;
  font-size: 16px;
  font-style: italic;
  color: #1a2b64;
  @media (max-width: 768px) {
    margin: 15px 0 11px 0;
    font-size: 14px;
  }
`;
const TeamButtonWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`
  display: flex;
  flex-wrap: wrap;
  width: 170px;
  gap: 4px;
`;
const TeamButton = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().button)`
  color: #767676;
  background: #f9f9f9;
  border: 1px solid #e0e0e0;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 80px;
  height: 24px;
  line-height: 24px;
  font-size: 12px;
  font-weight: bold;
  @media (max-width: 768px) {
    font-size: 11px;
    width: 70px;
  }
`;
const Team = ({ team  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const queryId = router.query.id;
    const List = [
        {
            name: "구단소개",
            href: `/team/${queryId}/introduction`
        },
        {
            name: "코칭스태프",
            href: `/team/${queryId}/coach`
        },
        {
            name: "선수소개",
            href: `/team/${queryId}/players`
        },
        {
            name: "팀기록",
            href: `/team/${queryId}/record`
        },
        {
            name: "총평",
            href: `/team/${queryId}/review`
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamWrapper, {
            children: team.map((team)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamBox, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LogoImage, {
                            src: team.team_logo
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TeamContentBox, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamTitle, {
                                    children: team.name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamButtonWrapper, {
                                    children: List.map((data, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TeamButton, {
                                            onClick: ()=>router.push({
                                                    pathname: data.href,
                                                    query: {
                                                        team_id: team.id
                                                    }
                                                }),
                                            children: data.name
                                        }, idx))
                                })
                            ]
                        })
                    ]
                }, team.id))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Team);


/***/ }),

/***/ 4176:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DE": () => (/* reexport safe */ _Team_TeamDetails_TeamDetails__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "MD": () => (/* reexport safe */ _SubNavgation_SubNavgation__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "XH": () => (/* reexport safe */ _Team_TeamList__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "e3": () => (/* reexport safe */ _Team_TeamDetails_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "h4": () => (/* reexport safe */ _Header_Header__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "m3": () => (/* reexport safe */ _Auth_Login_Login__WEBPACK_IMPORTED_MODULE_2__.Z)
/* harmony export */ });
/* harmony import */ var _Header_Header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7550);
/* harmony import */ var _SubNavgation_SubNavgation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5871);
/* harmony import */ var _Auth_Login_Login__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5696);
/* harmony import */ var _Auth_Register_Register__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8321);
/* harmony import */ var _Team_TeamList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3517);
/* harmony import */ var _Team_TeamDetails_TeamDetails__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8700);
/* harmony import */ var _Team_TeamDetails_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9210);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Auth_Login_Login__WEBPACK_IMPORTED_MODULE_2__, _Team_TeamDetails_TeamDetails__WEBPACK_IMPORTED_MODULE_5__, _Team_TeamDetails_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_6__]);
([_Auth_Login_Login__WEBPACK_IMPORTED_MODULE_2__, _Team_TeamDetails_TeamDetails__WEBPACK_IMPORTED_MODULE_5__, _Team_TeamDetails_TeamPlayers_PlayerDetails_PlayerDetails__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6107:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ client),
/* harmony export */   "u": () => (/* binding */ TokenClient)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _config_config_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6626);
/* harmony import */ var _Storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6855);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const client = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: _config_config_json__WEBPACK_IMPORTED_MODULE_1__/* .SERVER */ .c,
    headers: {
        "Content-Type": "application/json"
    }
});
const TokenClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: _config_config_json__WEBPACK_IMPORTED_MODULE_1__/* .SERVER */ .c,
    headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${(0,_Storage__WEBPACK_IMPORTED_MODULE_2__/* .getToken */ .L)()}`
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6855:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ TestToken),
/* harmony export */   "L": () => (/* binding */ getToken)
/* harmony export */ });
const getToken = ()=>{
    if (false) {}
};
const TestToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoibmphc3MyMSJ9.dKMIkqJf8-HYRxJHWGh5P7FyaWFiiQjiZlnjhNDyUFY";


/***/ }),

/***/ 6626:
/***/ ((module) => {

module.exports = JSON.parse('{"c":"http://127.0.0.1:8000"}');

/***/ })

};
;